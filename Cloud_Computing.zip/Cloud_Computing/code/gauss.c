#include <stdio.h>
#include <stdlib.h>
#include<math.h>
#include <time.h>
//#include "mkl_lapacke.h"

//using namespace std;


//#define N 4

//genere une matrice de taille sizexsize
double *generate_matrix(int size){
    int i;
    double *matrix=(double *)malloc(sizeof(double) * size * size);
    srand(1);

    for (i = 0; i < size * size; i++)
    {
        matrix[i] = rand() % 100;
    }

    return matrix;
}
double *generate_matrixx(int size){
    int i;
    double *matrix=(double *)malloc(sizeof(double) * size * size);
    srand(1);

    for (i = 0; i < size * size; i++)
    {
        matrix[i] = rand() % 50;
    }

    return matrix;
}


//affichage de la matrice
void print_matrix(const char *name, double *matrix, int size)
{
    int i, j;
    printf("matrix: %s \n", matrix);

    for (i = 0; i < size; i++)
    {
            for (j = 0; j < size; j++)
            {
                printf("%f ", matrix[i * size + j]);
            }
            printf("\n");
    }
}

int check_result(double *bref, double *b, int size) {
    int i;
    for(i=0;i<size*size;i++)
    {




      //troncade methode to approximate the O- and 0+ to 0
      	bref[i]=bref[i]*100;
      	b[i]=b[i]*100;
      	b[i]=truncf(b[i]);
      	bref[i]=truncf(bref[i]);
      	b[i]=b[i]/100;
      	bref[i]=bref[i]/100;
        if (bref[i]!=b[i])
          return 0;
    }
    return 1;
}
//fonction pour transformer la matrice A en matrice triangulaire inferieur
/*
A=(a11  a12  a13)
  (0    a22  a23)
  (0    0    a33)
*/
int EliminationPreced(double *A,double *B, int size);

// fonction qui calcule les valeures des inconnus
void NombreInconnus(double *A,double *B, int size);
int resolution(double *A,double*B,int size);
// fonction pour avoir le resultat de gauss
void Gauss_Jordan(double *A,double *B,int size)
{

    int Point_de_pivot = EliminationPreced(A,B,size);

    if (Point_de_pivot != -1)
    {
        printf("Matrice singuliere.\n");

        if (A[Point_de_pivot*size+size])
            printf("Systeme insolvable.");
        else
            printf("On a une infinité de solutions.");

        return;
    }

    NombreInconnus(A,B,size);
}
// fonction pour intervertir 2 lignes differentes
void swap_row(double *A, int i, int j,int size)
{

    for (int k=0; k<=size; k++)
    {
        double temp = A[i*size+k];
        A[i*size+k] = A[j*size+k];
        A[j*size+k] = temp;
    }
}

// fonction d'affichage de matrice
void print(double *A,int size)
{
    for (int i=0; i<size; i++, printf("\n"))
        for (int j=0; j<=size; j++)
            printf("%lf ", A[i*size+j]);
        printf("\n");
    printf("\n");
}

// fonction
int EliminationPreced(double *A,double *B,int size)
{
  //on boucle sur la longueur de A (size)
    for (int k=0; k<size; k++)
    {
        // Initialize maximum value and index for pivot
        int i_max = k;
        int v_max = A[i_max*size+k];
        int b_max=B[i_max*size+k];
        /* find greater amplitude for pivot if any */
        for (int i = k+1; i < size; i++)
            if (abs(A[i*size+k]) > v_max)
                v_max = A[i*size+k], i_max = i;

        /* if a prinicipal diagonal element  is zero,
         * it denotes that matrix is singular, and
         * will lead to a division-by-zero later. */
        if (!A[k*size+i_max])
            return k; // Matrix is singular

        /* Swap the greatest value row with current row */
        if (i_max != k)
            swap_row(A, k, i_max,size);
            swap_row(B,k,i_max,size);

        for (int i=k+1; i<size; i++)
        {
            /* factor f to set current row kth element to 0,
             * and subsequently remaining kth column to 0 */
            double f = A[i*size+k]/A[k*size+k];
            double m=B[i*size+k]/B[k*size+k];
            /* subtract fth multiple of corresponding kth
               row element*/
            //for (int j=k+1; j<=size; j++)
                //A[i*size+j] -= A[k*size+j]*f;
                //B[i*size+j] -= B[k*size+j]*f;

            /* filling lower triangular matrix with zeros*/
            B[i*size+k] = 0;
            A[i*size+k]=0;
        }
      //  printf("k= %f :",i);

      /*  print_matrix("A",A,size);
        printf("\n");
        printf("\n");
        print_matrix("B",B,size);
        printf("\n");   */     //for matrix state
    }
    //printf("A l'indice %f :",k);
  /*  printf("\n");
    print_matrix("A",A,size);
    printf("\n");
    printf("\n");
    print_matrix("B",B,size);
    printf("\n");   */         //for matrix state
    return -1;
}

// function to calculate the values of the unknowns
void NombreInconnus(double *A,double *B,int size)
{

    double x[size];  // An array to store solution

    /* Start calculating from last equation up to the
       first */
    for (int i = size-1; i >= 0; i--)
    {
        /* start with the RHS of the equation */
        x[i] = B[i*size+size]/A[i*size+size];

        /* Initialize j to i+1 since matrix is upper
           triangular*/
        for (int j=i+1; j<size; j++)
        {
            /* subtract all the lhs values
             * except the coefficient of the variable
             * whose value is being calculated */
            x[i] -= A[i*size+j]*x[j];
        }

        /* divide the RHS by the coefficient of the
           unknown being calculated */
        x[i] = x[i]/A[i*size+i];
    }

    printf("\nSolution for the system:\n");
    for (int i=0; i<size; i++)
        printf("%lf\n", x[i]);
}
int resolution(double *A,double*B,int size){
// double *x=(double*)malloc(sizeof(double) * size * size);
  //from the bottom to the top


//  int n= size;

  //h=size;

  /*for (int k=0;k<size;k++){
    for (int i=size-1;i>=0;i--){
      //from de right to the left
      for (int j=size-1;j>=i;j--){
        double stock=0;
        if (i==j){
          x[i*size+k]=(B[i*size+k]-stock)/A[i*size+j];}
        else{
          stock+=A[i*size+j]*x[j*size+k];
        }

    }
  }//j=k

}return x;*/
  int j;
  int r=-1;
  int t;
  double max;
  int i;
  int k;
  int g;
  int h;
  for (j=0;j<size;j++){
    /* code */
    //je cherche les val max des col k
    max=sqrt(A[(r+1)*size +j]*A[(r+1)*size +j]);
    k=r+1;
    for (t=r+1;t<size;t++)
    {
        if(A[t*size+j]> max)
        {
            max=sqrt(A[t*size+j]*A[t*size+j]);
            k=t;
        }
    }
    // If the max !=0 then we divide the line by the maximum
    //divide the line by the max while max is differents 0

    int m = size;
    if(A[k*size+j]!= 0)
    {
        double denom,b;
        r=r+1;

        denom=A[k*size+j];
        // We divide in A
        for(t=0;t<size;t++)
        {
            A[k*size+t] = A[k*size+t]/denom ;
        }
        // We divide in B
        for(t=0;t<size;t++)
        {
            B[k*size+t]=B[k*size+t]/denom ;
        }
        if(k!=r)
        {
            // we exhange the ligne in the matrix A
            for(t=0;t<size;t++)
            {
                b=A[k*size+t];
                A[k*size+t]=A[r*size+t];
                A[r*size+t]=b;
            }
            // we exhange the ligne in the matrix B
            for(t=0;t<size;t++)
            {
                b=B[k*size+t];
                B[k*size+t]=B[r*size+t];
                B[r*size+t]=b;
            }
        }
        // We substract the others rows
        for(i=0;i<size;i++)
        {
            if(i!=r)
            {
                denom=A[i*size+j];
                //calcul in matrix B
                for(t=0;t<size;t++)
                {
                    B[i*size+t]=B[i*size+t]-B[r*size+t]*denom;
                }
                //Calculs dans A
                for(t=0;t<size;t++)
                {
                    A[i*size+t]=A[i*size+t]-A[r*size+t]*denom;
                }

            }
        }
    }
  }
  //to change -0.0 value to 0
  for ( i = 0; i < (size+1)*(size+1); i++) {
    if (A[i] == -0.0) {
        A[i]= +0.0;
  for ( i = 0; i < (size+1)*(size+1); i++) {
    if (B[i] == -0.0) {
        B[i]= +0.0;
}
    /* code */
}}}
}
int my_dgesv(int n, int nrhs, double *a, int lda, int *ipiv, double *b, int ldb) {

    //Replace with your implementation
    // LAPACKE_dgesv : fait une decomposition LU directement
    //LAPACKE_dgesv(LAPACK_ROW_MAJOR, n, nrhs, a, lda, ipiv, b, ldb);
    // Il existe différentes methodes :
    // ICI je coderais la méthode du pivot de GAUSS

}

//double *gausspivo[t(double []*a,double *b,int size){
//}
    int main(int argc, char *argv[])
    {
      //size = la valeure donnée en argument
      int size = atoi(argv[1]);
      //print(B);
        double *a, *aref;
        double *b, *bref;
        a = generate_matrix(size);
        aref = generate_matrix(size);
        b = generate_matrix(size);
        bref = generate_matrix(size);
        //print_matrix("A", a, size);
        //print_matrix("B", b, size);
        // Using MKL to solve the system
        //MKL_INT n = size, nrhs = size, lda = size, ldb = size, info;
        //MKL_INT *ipiv = (MKL_INT *)malloc(sizeof(MKL_INT)*size);
        //clock_t tStart = clock();
        //info = LAPACKE_dgesv(LAPACK_ROW_MAJOR, n, nrhs, aref, lda, ipiv, bref, ldb);
        //printf("Time taken by MKL: %.2fs\n", (double)(clock() - tStart) / CLOCKS_PER_SEC);
        ///print_matrix("A", aref, size);
        //print_matrix("B", bref, size);
        clock_t tStart = clock();
        //MKL_INT *ipiv2 = (MKL_INT *)malloc(sizeof(MKL_INT)*size);
        resolution(a,b,size);
        printf("Time taken by my implementation: %.2fs\n", (double)(clock() - tStart) / CLOCKS_PER_SEC);
        if (check_result(bref,b,size)==1)
            printf("Result is ok!\n");
        else
            printf("Result is wrong!\n");
}
